/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Enum.java to edit this template
 */
package model.enums;

/**
 *
 * @author jorge-victor
 */
public enum FormaCobranca {
    POR_NOITE,
    FIXO,
    POR_UNIDADE;
}
